// alert('hello world');
document.write("<h2>Hello World</h2>");
document.write("<hr>");
document.write("<p>Good morning");