//object literal

let std1 = {
    fname : "Ramesh",
    lname : "Verma",
    marks : 98,
    email:"rv@gmail.com",
    id : "cs_12",
    is_in_merit:true
}

console.log('javascript object');
console.log(std1);
// console.log(std1.fname);
// console.log(std1.marks);

//JSON : Javascript Serialized Object Notation 
//Converting JS object into JSON string
let jsonString = JSON.stringify(std1);
console.log('corresponding json string');
console.log(jsonString);//json string

//Converting JSON string into javascript object

let outObj = JSON.parse(jsonString);
console.log('corresponding javascript object');
console.log(outObj);


