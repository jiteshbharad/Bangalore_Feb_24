let std1={
    fname : 'john',
    lname:  'paul',
    marks: 92 
};
 
let addr = {
    hno: 23,
    street:'abc',
    city:'new mumbai',
    state:'mh',
    manager : std1
}

std1.address = addr;
addr.manager = std1;

console.log(std1);

let str = JSON.stringify(std1);//Cannot convert circular object into json string
console.log(str);